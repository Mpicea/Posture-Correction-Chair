package com.example.monthtest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class main extends Activity {
    private static String SERVER_IP = "";
    private static final int SERVER_PORT = 8080;
    String responseD="";
    String[] data, testdata;
    LinearLayout bar;
    int total, texttotal, good, textgood, bad, textbad;
    private TextView ShowText;
    private Button btnMain, btnSelf, btnAnalyze, btnSetting;
    PieChart pieChart;
    private  static  String TAG = "MainActivit";
    private  float[] yData = {10,1,9};
    private  String[] xData = {"Good","Bad"};
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        pieChart=findViewById(R.id.pieChart);
        ShowText=findViewById(R.id.timeshow);
        bar = findViewById(R.id.bar);
        btnMain=(Button)findViewById(R.id.goMain);
        btnSelf=(Button)findViewById(R.id.goSelf);
        btnAnalyze=(Button) findViewById(R.id.goAnalyze);
        btnSetting=(Button)findViewById(R.id.goSetting);

        // 전달받은 서버 확인
        Intent intent = getIntent();
        String signal = intent.getStringExtra("IP");
        SERVER_IP = signal;
        // 서버에 데이터 요청
        NetworkTask networkTask = new NetworkTask();
        networkTask.execute("main_page");


        //메인 이동 버튼
        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), main.class);
                intent.putExtra("IP", SERVER_IP);
                startActivity(intent);
            }
        });
        //자가진단 이동 버튼
        btnSelf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SelfDiagnosis.class);
                intent.putExtra("IP", SERVER_IP);
                startActivity(intent);
            }
        });
        //통계 이동 버튼
        btnAnalyze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), analyze.class);
                intent.putExtra("IP", SERVER_IP);
                startActivity(intent);
            }
        });
        //설정 이동 버튼
        btnSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Settings.class);
                intent.putExtra("IP", SERVER_IP);
                startActivity(intent);
            }
        });

        //텍스트 보여줌
        texttotal = Math.round((int)(yData[0])/60);
        textgood = Math.round((int)yData[1]/60);
        textbad = Math.round((int)yData[2]/60);
        ShowText.setText(String.format("총 앉은 시간 : 약 %d시간 " +
                "\n잘 앉은 시간 : 약 %d시간 " +
                "\n잘 못 앉은 시간 : 약 %d시간",texttotal,textgood,textbad));

        //파이차트를 그림
        showChart();

        myView mview= new myView(bar.getContext());
        bar.addView(mview);
    }
    //기본적인 파이차트 설정
    private void showChart(){
        pieChart.setDrawHoleEnabled(true);
        pieChart.setUsePercentValues(true);
        pieChart.setEntryLabelTextSize(16);
        pieChart.setEntryLabelColor(Color.WHITE);
        pieChart.getDescription().setEnabled(false);

        Legend l = pieChart.getLegend();
        l.setEnabled(false);

        addDataSet();
    }
    //파이차트에 값을 설정하고 조정함
    private void addDataSet() {


        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();

        for(int i = 0 ; i <xData.length;i++){
            yEntrys.add(new PieEntry(yData[i+1],xData[i % xData.length]));
        }

        for(int i = 0 ; i <xData.length;i++){
            xEntrys.add(xData[i]);
        }

        //create the DATA
        PieDataSet pieDataSet = new PieDataSet(yEntrys,"Time");
        pieDataSet.setValueTextSize(16);
        pieDataSet.setValueTextColor(Color.WHITE);

        //add colors to dataSet

        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.BLUE);
        colors.add(Color.RED);
        pieDataSet.setColors(colors);

        //create a pieData object

        PieData pieData = new PieData(pieDataSet);
        pieData.setValueFormatter(new PercentFormatter(pieChart));
        pieChart.setData(pieData);
        pieChart.invalidate();

    }
    public class myView extends View {
        public myView(Context context) {
            super(context);
            // TODO Auto-generated constructor stub
        }

        public void onDraw(Canvas canvas) {
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setColor(Color.BLACK);
            //canvas.drawColor(Color.YELLOW);

            int start = 25;
            int end=25;
            int j;
            Rect rect1 = new Rect(30,80,30+100,80+100);

            int i;
            for(i=0; i<responseD.length();i++){ //.charAt()
                end = start + 3;
                if(responseD.charAt(i) == '0'){paint.setColor(Color.WHITE);}
                else if(responseD.charAt(i) == '1'){paint.setColor(Color.BLUE);}
                else if(responseD.charAt(i) == '2'){paint.setColor(Color.RED);}
                else{paint.setColor(Color.BLACK);}
                rect1 = new Rect( start,0,end,150);
                canvas.drawRect(rect1, paint);
                //다음 시작점은 현재의 끝점
                start = end;
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(Color.BLACK);
            Rect rect2 = new Rect( 25,0,end,150);
            canvas.drawRect(rect2, paint);

        }

    }
    public class NetworkTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String message = params[0];
            try {
                // 서버에 연결 및 작업 수행
                Socket socket = new Socket(SERVER_IP, SERVER_PORT);

                // 서버에 요청 전송
                // 입출력 스트림 생성
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                // 서버로 데이터 전송
                out.println(message);

                // 서버로부터 데이터 수신
                String responseData = in.readLine();
                System.out.println("서버에서 받은 메시지: " + responseData);

                //아마 String[] data; 인것 같고
                //이거 쓸거면 변수 추가 해야함

                data=responseData.split("\\$");
                responseD= data[0];
                String mdata = data[1];
                testdata = mdata.split("\\:");

                String t1=testdata[0];
                String t2=testdata[1];
                String t3=testdata[2];
                total = Integer.parseInt(t1);
                good = Integer.parseInt(t2);
                bad = Integer.parseInt(t3);

                yData[0] = total;
                yData[1] = good;
                yData[2] = bad;

                // 결과 반환
                return "작업 완료";

            } catch (IOException e) {
                e.printStackTrace();
                return "작업 실패";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // 작업 완료 후 UI 업데이트 또는 페이지 이동 등 수행
            if (result.equals("작업 완료")) {
                // 페이지 이동 등 원하는 동작 수행

            } else {
                // 에러 처리
                //socket.close();
            }
        }
    }
}
